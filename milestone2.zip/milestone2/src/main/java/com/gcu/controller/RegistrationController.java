package com.gcu.controller;

import org.springframework.stereotype.Controller;

@Controller
public class RegistrationController {

}
