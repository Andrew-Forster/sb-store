package com.gcu.model;

public class RegistrationModel {

}
