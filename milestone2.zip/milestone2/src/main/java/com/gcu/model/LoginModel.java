package com.gcu.model;

public class LoginModel {

}
