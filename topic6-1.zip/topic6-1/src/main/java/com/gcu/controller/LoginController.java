package com.gcu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.gcu.business.OrdersBusinessServiceInterface;
import com.gcu.business.SecurityBusinessService;

@Controller
public class LoginController {
	
	@Autowired
	private OrdersBusinessServiceInterface service;
	
	@Autowired
	private SecurityBusinessService security;
	
	@GetMapping("/login")
	public String display(Model model) {
		
		// Display Login Form View
		model.addAttribute("title", "Login Form");
		return "login";
	}
	
	/*
	 * @PostMapping("/doLogin") public String doLogin(@Valid LoginModel loginModel,
	 * BindingResult bindingResult, Model model) {
	 * 
	 * List<OrderModel> orders = service.getOrders();
	 * 
	 * service.test(); // Check for validation errors if (bindingResult.hasErrors())
	 * { model.addAttribute("title", "Login Form"); return "login"; }
	 * 
	 * // Print the form values out System.out.println(String.
	 * format("Form with Username of %s and Password of %s",
	 * loginModel.getUsername(), loginModel.getPassword()));
	 * 
	 * model.addAttribute("orders", orders);
	 * security.authenticate(loginModel.getUsername(), loginModel.getPassword());
	 * 
	 * return "orders"; }
	 */

}
