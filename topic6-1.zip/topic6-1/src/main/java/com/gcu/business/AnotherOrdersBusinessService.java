package com.gcu.business;

import java.util.ArrayList;
import java.util.List;

import com.gcu.model.OrderModel;

public class AnotherOrdersBusinessService implements OrdersBusinessServiceInterface {
	
	@Override
	public void test() {
		System.out.println("Hello from the AnotherOrdersBusinessService");
	}
	
	@Override
	public List<OrderModel> getOrders() {
		
		//Create some Orders
		List<OrderModel> orders = new ArrayList<OrderModel>();
		orders.add(new OrderModel("10L", "00000000011", "Product 11", 11.00f, 11));
		orders.add(new OrderModel("11L", "00000000012", "Product 12", 12.00f, 12));
		orders.add(new OrderModel("12L", "00000000013", "Product 13", 13.00f, 13));
		orders.add(new OrderModel("13L", "00000000014", "Product 14", 14.00f, 14));
		orders.add(new OrderModel("14L", "00000000015", "Product 15", 15.00f, 15));
		return orders;
	}
	
	@Override
	public void init() {
		
		System.out.println("init() method for AnotherOrdersBusinessService called");
	}
	
	@Override
	public void destroy() {
		
		System.out.println("destroy() method for AnotherOrdersBusinessService called");
	}
	
	@Override
	public OrderModel getOrderById(String id) {
		return null;
	}

}
