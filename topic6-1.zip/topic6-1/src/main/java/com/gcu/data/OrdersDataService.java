package com.gcu.data;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gcu.data.entity.OrderEntity;
import com.gcu.data.repository.OrdersRepository;

@Service
public class OrdersDataService implements DataAccessInterface<OrderEntity> {
	
	@Autowired
	private OrdersRepository ordersRepository;
	
	/**
	 * Non-Default constructor for constructor injection
	 */
	public OrdersDataService(OrdersRepository ordersRepository) {
		this.ordersRepository = ordersRepository;
	}
	
	/**
	 * CRUD: finder to return single entity
	 */
	public OrderEntity findById(String id) {
		return ordersRepository.getOrderById(id);
	}
	
	/**
	 * CRUD: finder to return all entities
	 */
	public List<OrderEntity> findAll() {
		List<OrderEntity> orders = new ArrayList<>();
		
		try {
			// Get all the Entity Orders
			Iterable<OrderEntity> ordersIterable = ordersRepository.findAll();
			
			// Convert to a List and return the List
			orders = new ArrayList<OrderEntity>();
			ordersIterable.forEach(orders::add);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Return the List
		return orders;
	}
	
	/**
	 * CRUD: create an entity
	 */
	public boolean create(OrderEntity order) {
		try {
			this.ordersRepository.save(order);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean update(OrderEntity order) {
		return true;
	}
	
	public boolean delete(OrderEntity order) {
		return true;
	}

}
